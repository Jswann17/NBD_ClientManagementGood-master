﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NBD_ClientManagementGood.Models
{
    public class BidLB
    {
        //public int BidID { get; set; }

        //public virtual Bid Bids { get; set; }

        //public int LabourUnitID { get; set; }

        //public virtual LabourUnit LabourUnits { get; set; }
    }
}
