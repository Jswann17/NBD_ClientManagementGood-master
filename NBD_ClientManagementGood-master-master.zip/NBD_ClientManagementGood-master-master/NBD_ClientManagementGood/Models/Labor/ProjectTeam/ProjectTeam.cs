﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NBD_ClientManagementGood.Models
{
    public class ProjectTeam
    {
        //public int ProductionID { get; set; }

        //public virtual Production Production { get; set; }

        //public int LabourDepartmentID { get; set; }

        //public virtual LabourDepartment LabourDepartment { get; set; }
    }
}
